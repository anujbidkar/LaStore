

const handleChange = (obj, name, value) => {
    obj[name] = value
    return obj
}

export {
    handleChange
}