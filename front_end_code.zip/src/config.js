export const url = "https://lastoreapi.herokuapp.com";
// export const url = `http://localhost:3001`;
