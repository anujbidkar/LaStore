import React from 'react'

function My404Component() {
    return (
        <div>
            page not found
        </div>
    )
}

export default My404Component
